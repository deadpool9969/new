// // Login.js
// import React, { useState } from "react";
// import { Button } from "react-bootstrap";
// import LoginModal from "./LoginModal";
// import "../Login/Login.css";

// function Login() {
//   const [modalShow, setModalShow] = useState(false);
//   const [mobileNumber, setMobileNumber] = useState("");
//   const [step, setStep] = useState("enterNumber");

//   return (
//     <div>
//       <LoginModal
//         show={modalShow}
//         onHide={() => {
//           setModalShow(false);
//           setStep("enterNumber"); // Reset step when modal closes
//         }}
//         mobileNumber={mobileNumber}
//         setMobileNumber={setMobileNumber}
//         step={step}
//         setStep={setStep}
//       />
//       <Button variant="primary" onClick={() => setModalShow(true)}>
//         Modal
//       </Button>
//     </div>
//   );
// }

// export default Login;
