import React, { useRef, useEffect, useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import SvgIcon from "../svg/SvgIcon";
import { HiPencilAlt } from "react-icons/hi";
import axios from "axios";
import "../Login/Login.css";

function LoginModal({
  show,
  onHide,
  mobileNumber,
  setMobileNumber,
  step,
  setStep,
}) {
  const inputRefs = Array.from({ length: 6 }, () => useRef(null));
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  useEffect(() => {
    if (show && step === "enterNumber" && inputRefs[0].current) {
      inputRefs[0].current.focus();
    }
  }, [show, step]);

  useEffect(() => {
    if (step === "enterNumber") {
      setIsButtonDisabled(mobileNumber.length < 10);
    } else if (step === "enterOTP") {
      const isOtpComplete = inputRefs.every((ref) => ref.current.value !== "");
      setIsButtonDisabled(!isOtpComplete);
    }
  }, [mobileNumber, step]);

  const handleOTPInput = (e, index) => {
    const { value } = e.target;
    if (/^[0-9]$/.test(value)) {
      // Move to next input
      if (index < 5) {
        inputRefs[index + 1].current.focus();
      }
    } else {
      // Clear invalid input
      e.target.value = "";
    }
    checkOtpFields();
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !e.target.value && index > 0) {
      // Move to previous input
      inputRefs[index - 1].current.focus();
    }
  };

  const handleOTPSubmit = async () => {
    // Gather OTP from inputRefs
    const otp = inputRefs.map((ref) => ref.current.value).join("");
    console.log("OTP submitted:", otp);

    // Verify OTP
    try {
      const response = await axios.post(
        `https://api.allpos.in/users/login?mobile=${mobileNumber}&otp=${otp}`
      );
      console.log("OTP verification successful:", response.data);
      // Handle successful OTP verification (e.g., log in user)
      onHide();
    } catch (error) {
      console.error("OTP verification failed:", error);
      // Handle OTP verification failure (e.g., show an error message)
    }
  };

  const checkOtpFields = () => {
    const isOtpComplete = inputRefs.every((ref) => ref.current.value !== "");
    setIsButtonDisabled(!isOtpComplete);
  };

  const requestOTP = async () => {
    try {
      const response = await axios.post(
        `https://api.allpos.in/users/login?mobile=${mobileNumber}`
      );
      console.log("OTP request successful:", response.data);
      setStep("enterOTP");
    } catch (error) {
      console.error("OTP request failed:", error);
      // Handle OTP request failure (e.g., show an error message)
    }
  };

  const handleEditNumber = () => {
    setStep("enterNumber");
  };

  return (
    <div className="Praentmodal">
      <Modal
        className="header"
        show={show}
        onHide={onHide}
        // size="md"
        fullscreen
        aria-labelledby="contained-modal-title-vcenter"
        centered>
        <Modal.Body className="b-body">
          <div className="Confirmationlogout">
            <h4 className="TextLine">
              {step === "enterNumber"
                ? "Enter your mobile number"
                : "Enter the OTP sent to"}
              {step === "enterOTP" && (
                <Button
                  className="editNumberButton"
                  variant=""
                  onClick={handleEditNumber}>
                  {mobileNumber}
                  <HiPencilAlt className="pencil" />
                </Button>
              )}
            </h4>
            <Button className="exitButton" variant="link" onClick={onHide}>
              <SvgIcon icon="x" size="22" />
            </Button>
          </div>
          <div className="inputenter">
            {step === "enterNumber" ? (
              <Form.Group controlId="formMobileNumber">
                <Form.Control
                  className="number-input"
                  type="tel"
                  placeholder="Mobile Number"
                  maxLength={10}
                  pattern="[0-9]"
                  inputMode="numeric"
                  value={mobileNumber}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9]/g, "");
                    setMobileNumber(val);
                    setIsButtonDisabled(val.length < 10);
                  }}
                />
              </Form.Group>
            ) : (
              <div className="otp-input-container">
                {inputRefs.map((ref, index) => (
                  <Form.Control
                    key={index}
                    ref={ref}
                    type="text"
                    maxLength={1}
                    pattern="[0-9]*"
                    inputMode="numeric"
                    className="otp-input"
                    onChange={(e) => handleOTPInput(e, index)}
                    onKeyDown={(e) => handleKeyDown(e, index)}
                  />
                ))}
              </div>
            )}
          </div>
          <div>
            <Button
              className="ModalAction"
              variant="primary"
              onClick={step === "enterNumber" ? requestOTP : handleOTPSubmit}
              disabled={isButtonDisabled}>
              {step === "enterNumber" ? "Submit" : "Verify OTP"}
            </Button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default LoginModal;
