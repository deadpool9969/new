/* eslint-disable react/no-danger */
import React from "react";
import svgs from "./svg";

const SvgIcon = ({
  icon = "",
  className = "",
  size = null,
  width = 18,
  height = 18,
  fill = "#000000",
  stroke = "currentColor",
  strokeWidth = 1.5,
  strokeLinecap = "round",
  strokeLinejoin = "round",
  viewBox = "0 0 256 256",
  xmlns = "http://www.w3.org/2000/svg",
}) => {
  if (svgs[icon]) {
    if (size) {
      width = size;
      height = size;
    }

    return (
      <svg
        xmlns={xmlns}
        width={width}
        height={height}
        viewBox={viewBox}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeLinecap={strokeLinecap}
        strokeLinejoin={strokeLinejoin}
        className={`cs-icon ${icon} ${className}`}
        dangerouslySetInnerHTML={{ __html: svgs[icon] }}
      />
    );
  }
  console.log(`SvgIcon -> [${icon}] icon is not defined.`);
  return <></>;
};

export default React.memo(SvgIcon);
