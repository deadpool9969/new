import React, { useState, useEffect } from "react"; // Import useState and useEffect
import { Button, Modal } from 'react-bootstrap';
import { CiLocationOn } from 'react-icons/ci';
import { MdCurrencyRupee } from 'react-icons/md';
import { FaReact, FaChevronRight } from 'react-icons/fa';
import "../jobcardmodal/jobcard.css";

const Jobmodal1 = () => {
  const [Jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [show, setShow] = useState(false);
  const [Skillset, setSkillset] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await fetch('https://fakestoreapi.com/users'); 
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setJobs(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);
  
// ========================================

// useEffect(() => {
//   const fetchSkills = async () => {
//     try {
//       const response = await fetch('https://fakestoreapi.com/products');
//       if (!response.ok) {
//         throw new Error('Network response was not ok');
//       }
//       console.log(response);
//       const data = await response.json();
//       setSkillset(data);
//     } catch (error) {
//       setError(error.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   fetchJobs();
// }, []);

// ========================================



  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  const jobCards = Jobs.map(item => (
    <div key={item.id} className="jobcard-parent">
      <div className="jobcard">
        <div className="jobhead">
          <img
            src="https://imgs.search.brave.com/Cf4DZWFpdPm29sGP6dhMRWcabUrCoszRxpCZ3SYRBB0/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly90NC5m/dGNkbi5uZXQvanBn/LzAzLzU5LzQ2LzUx/LzM2MF9GXzM1OTQ2/NTE0Ml8zVlBSVUZx/dW5KaXR1UXFOYXc5/SVFUSHlWYTg2T0Zw/SC5qcGc"
            alt=""
          />
          <div className="description-head">
            <h2>{item.name.firstname}</h2>
            <div className="job-description">
              <h3>{item.email || 'Description not available'}</h3>
            </div>
          </div>
        </div>
        <div className="location">
          <div className="loc">
            <CiLocationOn />
            <p>{item.address.city || 'Location not specified'}</p>
          </div>
          <div className="ctc">
            <MdCurrencyRupee />
            <p>{item.address.number || 'Salary range not specified'}</p>
          </div>
        </div>
        <div className="skills-required">
          {item.skills && item.skills.map(skill => (
            <div key={skill} className="skilltag">
              <div className="skillicon">
                <p><FaReact /> {skill}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="apply-btn">
          <button className="apply">Apply</button>
        </div>
      </div>
    </div>
  ));

  const searchItems = [
    { id: 1,  title: "Opportunities for Freshers" },
    { id: 2,  title: "Work from Home Opportunities" },
    { id: 3,  title: "Part Time Opportunities" },
    { id: 4,  title: "Jobs for Women" },
    { id: 5,  title: "International Jobs" },
    { id: 6,  title: "Hello" },
  ];


  return (
    <div>
      <h1 className="searches">POPULAR SEARCHES</h1>
      <div className="parent">
        {searchItems.map((item) => (
          <div key={item.id} className="img1">
            <div className="card1">
              <p>{item.trending}</p>
              <h2>{item.title}</h2>
              <button onClick={() => setShow(true)}>View all<FaChevronRight className="FaChevronRight" /></button>
            </div>
          </div>
        ))}
      </div>
      <Modal 
        show={show}
        onHide={() => setShow(false)}
        fullscreen
        aria-labelledby="example-custom-modal-styling-title"
      >
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            Job Name
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="job-container">
            <div className="fade-effect top"></div>
            {jobCards}
            <div className="fade-effect bottom"></div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Jobmodal1;
