import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import "./App.css";
import Slider from "./component/Slider";
import Jobcard from "./component/Jobcard";
import "./component/jobcard.css";
import Footer from "./component/Footer";
import Registration from "./Registration/Registration";
import logo from "./svg/SkyQ-Tech-logo.svg";
import profilelogo from "./svg/person-circle.svg";
import { CiLocationOn } from "react-icons/ci";
import LoginModal from "../src/Login/LoginModal";
import Jobs from "./component/Jobs";
import Jobmodal1 from "./jobcardmodal/Jobcard1";

import { useNavigate } from "react-router-dom";
import Dropdown from "react-bootstrap/Dropdown";
import { CgProfile } from "react-icons/cg";
import { IoMdLogIn } from "react-icons/io";
import { RiLogoutCircleLine } from "react-icons/ri";
import RegistrationCard from "./Registration/RegistrationCard";
import { FaLocationCrosshairs } from "react-icons/fa6";




function App() {
  const navigate = useNavigate();

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const [modalShow, setModalShow] = useState(false);
  const [mobileNumber, setMobileNumber] = useState("");
  const [step, setStep] = useState("enterNumber");

  useEffect(() => {
    const timer = setTimeout(() => {
      setModalShow(true);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const handleProfileClick = () => {
    navigate("./component/Profile/Profile");
  };

  return (
    <div className="App">
      <RegistrationCard />
      <div className="appHeader">
        <div className="left">
          <img className="logo" src={logo} alt="SkyQ Tech Logo" />
        </div>
        <div className="right">
          <LoginModal
            show={modalShow}
            onHide={() => {
              setModalShow(false);
              setStep("enterNumber");
            }}
            mobileNumber={mobileNumber}
            setMobileNumber={setMobileNumber}
            step={step}
            setStep={setStep}
          />
          <Dropdown>
            <Dropdown.Toggle
              className="headerButton"
              variant="success"
              id="dropdown-basic"
            >
              <img
                className="profile-logo"
                src={profilelogo}
                alt="person circle"
              />
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item onClick={handleProfileClick}>
                <CgProfile /> &nbsp;&nbsp; Profile
              </Dropdown.Item>
              <Dropdown.Item
                href="#/action-1"
                onClick={() => setModalShow(true)}
              >
                <IoMdLogIn /> &nbsp;&nbsp;Login
              </Dropdown.Item>
              <Dropdown.Item href="#/action-2">
                <RiLogoutCircleLine /> &nbsp;&nbsp; Log out
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>

      <div className="home-container">
        <div className="card text-white">
          <div className="card-img-overlay">
            <h5 className="card-title">FIND FULL/PART TIME WORK</h5>
            <div className="location">
              <CiLocationOn className="Cilocation" />
              {/* <input type="text" className="textfeild" id="email1" placeholder="Mumbai..."/> */}
              <FaLocationCrosshairs class="FaLocationCrosshairs" />
              <h5>Mumbai...</h5>
            </div>
          </div>
        </div>
      </div>

      <Slider />

      {/* <Jobcard /> */}

      <Jobmodal1 />

      {/* <Jobs /> */}

      <Footer />
    </div>
  );
}

export default App;
