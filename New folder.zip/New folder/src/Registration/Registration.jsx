import React from "react";
import RegistrationCard from "./RegistrationCard";

function Registration() {
  return (
    <div>
      <RegistrationCard />
    </div>
  );
}

export default Registration;
