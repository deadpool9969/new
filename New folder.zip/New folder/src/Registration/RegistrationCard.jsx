import React, { useState, useRef, useEffect } from "react";
import { Modal, Button, Form, Dropdown } from "react-bootstrap";
import SvgIcon from "../svg/SvgIcon";
import { CiLocationOn } from "react-icons/ci";
import "../Registration/Registration.css";

function RegistrationCard() {
  const [show, setShow] = useState(false);
  const [selectedDay, setSelectedDay] = useState(1); // Default value
  const [selectedMonth, setSelectedMonth] = useState(1); // Default value
  const [selectedYear, setSelectedYear] = useState(
    new Date().getFullYear() - 18
  );

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const currentYear = new Date().getFullYear();
  const startYear = currentYear - 18;
  const MonthOptions = Array.from({ length: 12 }, (_, i) => i + 1);
  const DayOptions = Array.from({ length: 30 }, (_, i) => i + 1);
  const YearOptions = Array.from(
    { length: currentYear - startYear + 49 },
    (_, i) => startYear - i
  );

  // Handler for day change
  const handleDayChange = (day) => {
    setSelectedDay(day);
    // Optionally, reset month and year selections
    setSelectedMonth(1);
    setSelectedYear(startYear);
  };

  // Handler for month change
  const handleMonthChange = (month) => {
    setSelectedMonth(month);
    // Reset day selection
    setSelectedDay(1);
  };

  useEffect(() => {
    // Open the modal for 1 minute
    const timer = setTimeout(() => {
      setShow(false);
    }, 6000); // Set timeout to 1000ms for testing purposes

    // Cleanup function to clear the timeout if the component unmounts before the timeout completes
    return () => clearTimeout(timer);
  }, [setShow]);

  // Handler for year change
  const handleYearChange = (year) => {
    setSelectedYear(year);
    // Reset month and day selections
    setSelectedMonth(1);
    setSelectedDay(1);
  };

  return (
    <div>
      <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>
      <Modal
        show={show}
        onHide={handleClose}
        size="md"
        backdrop="static"
        aria-labelledby="contained-modal-title-vcenter"
        centered>
        <Modal.Body>
          <h3> Registration</h3>
          {/* <Button className="exitButton" variant="link" onClick={handleClose}>
            <SvgIcon icon="x" size="22" />
          </Button> */}
          <Form.Group>
            <p>Full Name</p>
            <Form.Control type="text" placeholder="Full Name" />
            <p> Contect No.</p>
            <Form.Control type="text" placeholder="Contect No." />
            <p>Email</p>
            <Form.Control type="text" placeholder="@gmail.com" />
            <p>Location</p>
            <div className="input-with-icon">
              <Form.Control type="text" placeholder="City" />
              {/* <span className="icon">
                <CiLocationOn />
              </span> */}
            </div>
            <div className="Drop-Age">
              <p>Date of Birth</p>
              <Dropdown>
                <Dropdown.Toggle variant="light" id="dropdown-basic">
                  {selectedDay}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  style={{ maxHeight: "165px", overflowY: "auto" }}>
                  {DayOptions.map((option, k) => (
                    <Dropdown.Item
                      key={k}
                      onClick={() => handleDayChange(option)}>
                      {option}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
              <Dropdown>
                <Dropdown.Toggle variant="light" id="dropdown-basic">
                  {selectedMonth}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  style={{ maxHeight: "165px", overflowY: "auto" }}>
                  {MonthOptions.map((option, k) => (
                    <Dropdown.Item
                      key={k}
                      onClick={() => handleMonthChange(option)}>
                      {option}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
              <Dropdown>
                <Dropdown.Toggle variant="light" id="dropdown-basic">
                  {selectedYear}
                </Dropdown.Toggle>
                <Dropdown.Menu
                  style={{ maxHeight: "165px", overflowY: "auto" }}>
                  {YearOptions.map((option, k) => (
                    <Dropdown.Item
                      key={k}
                      onClick={() => handleYearChange(option)}>
                      {option}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </Form.Group>
          <Button
            variant="primary"
            onClick={handleClose}
            style={{ width: "100%" }}>
            Save
          </Button>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default RegistrationCard;
