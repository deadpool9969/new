import React from "react";
import "../component/footer.css";
import { FaRegCopyright } from "react-icons/fa";
import logo from "../svg/SkyQ-Tech-logo.svg";

const Footer = () => {
  return (
    <div>
      <div class="footer-img">
        <a href="https://skyq.tech/">
          <img className="logo" src={logo} alt="SkyQ Tech Logo" />
        </a>
      </div>

      <div class="copyright">
        <div class="copy-icon">
          <FaRegCopyright />
        </div>
        <p>2022 Brand, Inc. • privacy • terms</p>
      </div>
    </div>
  );
};

export default Footer;
