import React, { useState, useEffect } from "react";
import axios from "axios";
import "../skillslider/slider.css";
import { FaUser, FaCamera, FaVideo, FaSearch, FaKeyboard, FaCode, FaMapMarkerAlt, FaCalendarAlt, FaEnvelope } from 'react-icons/fa';
import { MdContactSupport } from "react-icons/md";



const Slider = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Replace this URL with your actual API endpoint
    const skillsApiUrl = 'http://192.168.0.110:3000/api/skill'; 

    const fetchSkills = async () => {
      try {
        const response = await axios.get(skillsApiUrl);
        console.log(response);
        const skillsData = response.data.map(skill => ({
          title: skill.title,
          icon: skill.icon // Ensure the API response includes the icon names or URLs
        }));
        
        setSkills(skillsData);
      } catch (err) {
        setError("Error fetching skills data.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSkills();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  // Sample icons - ensure these match your API's icon names or use appropriate mapping
  const iconMapping = {
    "FaUser": FaUser,
    "FaCamera": FaCamera,
    "FaVideo": FaVideo,
    "FaSearch": FaSearch,
    "FaKeyboard": FaKeyboard,
    "FaCode": FaCode,
    "MdContactSupport": MdContactSupport,
  };

  // Map icon names from the API to actual React components
  const mapIcon = (iconName) => {
    return iconMapping[iconName] || FaUser; // Fallback to FaUser if icon not found
  };

  const duplicatedSkills = [...skills, ...skills, ...skills]; // Duplicate the skills array
  const duplicatedDetails = [...userDetails, ...userDetails, ...userDetails, ...userDetails, ...userDetails, ...userDetails]; // Duplicate the userDetails array

  return (
    <div>
      <div className="skill-slider">
        <div className="skill-track">
          {duplicatedSkills.map((skill, index) => (
            <div className="skill-item" key={index}>
              <div className="skill-set">
                <div className="skill-icon">
                  {React.createElement(mapIcon(skill.icon))}
                </div>
                <div className="stitle">
                  <h4>{skill.title}</h4>
                  {/* Removed skill.openings as it is not defined */}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="skill-slider">
        <div className="skill-track">
          {duplicatedDetails.map((detail, index) => (
            <div className="skill-item" key={index}>
              <div className="skill-set">
                <div className="skill-icon">
                  {React.createElement(detail.icon)}
                </div>
                <div className="stitle">
                  <h4>{detail.title}</h4>
                  <p>{detail.detail}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Slider;
