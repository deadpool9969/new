import React from "react";
import "../component/jobcard.css"
import { MdKeyboardArrowRight } from "react-icons/md";

const Jobcard = () => {
  const searchItems = [
    { id: 1, title: "Opportunities for Freshers" },
    { id: 2, title: "Work from Home Opportunities" },
    { id: 3, title: "Part Time Opportunities" },
    { id: 4, title: "Jobs for Women" },
    { id: 5, title: "International Jobs" },
    { id: 6, title: "Hello" },
  ];
  return (
    <div>
      <h1 className="searches">POPULAR SEARCHES</h1>
      <div className="parent">
        {searchItems.map((item) => (
          <div key={item.id} className="img1">
            <div className="card1">
              <p>{item.trending}</p>
              <h2>{item.title}</h2>
              <button>View all <MdKeyboardArrowRight /> </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Jobcard;
