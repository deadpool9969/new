import React, { useState, useEffect } from "react";
import axios from "axios";
import "../component/slider.css";

// Define the initial states
const Slider = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Replace with your actual API URL
    const fetchSkills = async () => {
      try {
        const response = await axios.get('https://fakestoreapi.com/users');
        // Adjust the data structure according to your API response
        console.log(response);
        setSkills(response.data);
      } catch (err) {
        setError("Error fetching skills data.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSkills();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;


  
  return (
    <>
      <div className="skill-slider">
        <div className="skill-track1">
          {skills.concat(skills).map((skill, index) => (
            <div className="skill-item" key={index}>
              <div className="skill-set">
                <div className="skill-icon">
                  {/* Assuming your API provides icon class names */}
                  <i className={`fa-solid ${skill.iconClass}`}></i>
                </div>
                <div className="stitle">
                  <h4>{skill.name.firstname}</h4>
                  <p>{skill.openings}</p> {/* If `openings` is not in the API response, remove or adjust this */}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="skill-slider">
        <div className="skill-track2">
          {skills.concat(skills).map((skill, index) => (
            <div className="skill-item" key={index}>
              <div className="skill-set">
                <div className="skill-icon">
                  {/* Assuming your API provides icon class names */}
                  <i className={`fa-solid ${skill.iconClass}`}></i>
                </div>
                <div className="stitle">
                  <h4>{skill.name.lastname}</h4>
                  <p>{skill.openings}</p> {/* If `openings` is not in the API response, remove or adjust this */}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Slider;
