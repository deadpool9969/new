import React from "react";
import "./Profile.css";
import Slider from "../skillslider/Slider";
import { FaPhoneAlt } from "react-icons/fa";
import { BiLogoGmail } from "react-icons/bi";
import { RiWhatsappFill } from "react-icons/ri";

function Profile() {
  return (
    <>
      <div className="main-container">
        <div className="img">
          <img src="./profile.jpg" alt="Profile" />
        </div>
      </div>
      <div className="slide">
        <Slider/>
      </div>
      <div className="profile">
        <div className="info">
          <div className="info-container">
            <h2>Steave Jobs</h2>
            <p>
              Simple and user-friendly navigation makes a great mobile app, and
              this is true for other pages too. Menu options should be easy to
              reach, and there shouldn’t be too many of them
            </p>
          </div>
        </div>
        <div className="edit">
          <a href="tel:+918452921123">
            <button>
              <FaPhoneAlt />
            </button>
          </a>
          <a href="https://wa.me/8291752420">
            <button>
              <RiWhatsappFill />
            </button>
          </a>
          <a href="mailto:omkarkale688@gmail.com">
            <button>
              <BiLogoGmail />
            </button>
          </a>
          <button>Edit</button>
        </div>
        <div className="portfolio">
          <div className="navig">
            <h2 className="port">Portfolio</h2>
            <h2 className="about">About</h2>
          </div>
          <div className="portfolio-post">
            <div className="line1">
              <div className="postinfo">
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut
                  possimus debitis eos quibusdam obcaecati temporibus veniam
                  cumque nisi, mollitia, quaerat quas perspiciatis aperiam
                  provident veritatis voluptate maiores dolorum, dolore eius
                  amet inventore assumenda odio!
                </p>
              </div>
              <img
                src="https://imgs.search.brave.com/Y2rH-Z9a2_btluX3LhROUI7M7jGi_vhClrX3FnB4yVA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9idXJz/dC5zaG9waWZ5Y2Ru/LmNvbS9waG90b3Mv/dGFubmVkLXNhbmQt/ZHVuZXMtc3Vycm91/bmRlZC1hbi1vcGVu/LXJlc2Vydm9pci5q/cGc_d2lkdGg9MTAw/MCZmb3JtYXQ9cGpw/ZyZleGlmPTAmaXB0/Yz0w"
                alt=""
              />
              <img
                src="https://imgs.search.brave.com/Y2rH-Z9a2_btluX3LhROUI7M7jGi_vhClrX3FnB4yVA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9idXJz/dC5zaG9waWZ5Y2Ru/LmNvbS9waG90b3Mv/dGFubmVkLXNhbmQt/ZHVuZXMtc3Vycm91/bmRlZC1hbi1vcGVu/LXJlc2Vydm9pci5q/cGc_d2lkdGg9MTAw/MCZmb3JtYXQ9cGpw/ZyZleGlmPTAmaXB0/Yz0w"
                alt=""
              />
            </div>

            <div className="line2">
              <div className="postinfo">
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut
                  possimus debitis eos quibusdam obcaecati temporibus veniam
                  cumque nisi, mollitia, quaerat quas perspiciatis aperiam
                  provident veritatis voluptate maiores dolorum, dolore eius
                  amet inventore assumenda odio!
                </p>
              </div>
              <img
                src="https://imgs.search.brave.com/Y2rH-Z9a2_btluX3LhROUI7M7jGi_vhClrX3FnB4yVA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9idXJz/dC5zaG9waWZ5Y2Ru/LmNvbS9waG90b3Mv/dGFubmVkLXNhbmQt/ZHVuZXMtc3Vycm91/bmRlZC1hbi1vcGVu/LXJlc2Vydm9pci5q/cGc_d2lkdGg9MTAw/MCZmb3JtYXQ9cGpw/ZyZleGlmPTAmaXB0/Yz0w"
                alt=""
              />
              <img
                src="https://imgs.search.brave.com/Y2rH-Z9a2_btluX3LhROUI7M7jGi_vhClrX3FnB4yVA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9idXJz/dC5zaG9waWZ5Y2Ru/LmNvbS9waG90b3Mv/dGFubmVkLXNhbmQt/ZHVuZXMtc3Vycm91/bmRlZC1hbi1vcGVu/LXJlc2Vydm9pci5q/cGc_d2lkdGg9MTAw/MCZmb3JtYXQ9cGpw/ZyZleGlmPTAmaXB0/Yz0w"
                alt=""
              />
              <img
                src="https://imgs.search.brave.com/Y2rH-Z9a2_btluX3LhROUI7M7jGi_vhClrX3FnB4yVA/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9idXJz/dC5zaG9waWZ5Y2Ru/LmNvbS9waG90b3Mv/dGFubmVkLXNhbmQt/ZHVuZXMtc3Vycm91/bmRlZC1hbi1vcGVu/LXJlc2Vydm9pci5q/cGc_d2lkdGg9MTAw/MCZmb3JtYXQ9cGpw/ZyZleGlmPTAmaXB0/Yz0w"
                alt=""
              />
            </div>
            <div className="line3">
              <img
                src="https://imgs.search.brave.com/v7gNQ32kMMOiPTsU9lcbNUGItjrMHg_Ibvy4X0SdrsU/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jZG4u/ZHJpYmJibGUuY29t/L3VzZXJ1cGxvYWQv/MTQ0MzY4NDkvZmls/ZS9zdGlsbC00Yzcy/YWY1MmFkOWY0MDA4/MWM2NDVkNTMzNDAx/MTZlMy5wbmc_cmVz/aXplPTQwMHgw"
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Profile;
