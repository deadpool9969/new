import React from 'react'
import './jobs.css'
const Jobs = () => {
    
        const searchItems = [
          { id: 1, trending: "We have requirement for Motherhood Hospital for Junior Consultant", title: "Front-end developers" },
          { id: 2, trending: "End-to-end sales of vacant and new properties through leads assigned in CRM", title: "Real Estate Sales Executive" },
          { id: 3, trending: "Required Agency Sales Officer", title: "Agency Sales Officer" },
        //   { id: 4, trending: "#Trending4", title: "Jobs for Women" },
        //   { id: 5, trending: "#Trending5", title: "International Jobs" },
        //   { id: 6, trending: "#Trending6", title: "Hello" },
        ];
  return (
    
      <div>
      <hr></hr>

      <div className="parent-job">
        {searchItems.map((item) => (
          <div key={item.id} className="job">
            <div className="job-card">
              <h2>{item.title}</h2>
              <p>{item.trending}</p>
              <button>View job </button>
            </div>
          </div>
        ))}
      </div>
    </div>
    
  )
}

export default Jobs
